#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
[ "$(id -u)" = 0 ] || { echo '请用 root 执行'; exit 1; }
conf=/etc/nginx/conf.d/sfapp-czy.conf
unit=/etc/systemd/system/guoyuan-app-visits.service
target=/opt/guoyuan-app-server/app-visits
[ -f "$conf" ] && [ ! -e "$unit" ] && [ ! -e "$target" ] || { echo '配置不存在或服务已存在，停止安装'; exit 1; }
python3 - "$conf" <<'PY'
import re, sys
s=open(sys.argv[1], encoding='utf-8').read()
if 'app-visit-events' in s or len(re.findall(r'(?m)^\s*location\s+/\s*\{',s)) != 1:
    raise SystemExit('APP Nginx 配置与预期不同，未修改。')
PY
mkdir -p "$target" /var/lib/guoyuan-app-visits
chmod 700 /var/lib/guoyuan-app-visits
cp visit_service.py "$target/visit_service.py"
cat > "$unit" <<'UNIT'
[Unit]
Description=Guoyuan APP visit event collector
After=network.target
[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/guoyuan-app-server/app-visits/visit_service.py
Restart=on-failure
RestartSec=3
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now guoyuan-app-visits.service
sleep 1
systemctl is-active --quiet guoyuan-app-visits.service || { echo '服务启动失败，Nginx 未修改'; exit 1; }
backup="${conf}.bak-visits-$(date +%Y%m%d%H%M%S)"
cp -a "$conf" "$backup"
python3 - "$conf" <<'PY'
import re, sys
p=sys.argv[1]
s=open(p,encoding='utf-8').read()
s,n=re.subn(r'(?m)^(\s*)location\s+/\s*\{',r'\1location = /app-visit-events {\n\1    proxy_pass http://127.0.0.1:21002;\n\1    client_max_body_size 1k;\n\1}\n\1location / {',s,count=1)
assert n == 1
open(p,'w',encoding='utf-8').write(s)
PY
if nginx -t; then
  systemctl reload nginx
else
  cp -a "$backup" "$conf"
  echo 'Nginx 检查失败，已恢复配置'; exit 1
fi
echo "完成。数据库：/var/lib/guoyuan-app-visits/visits.sqlite3；Nginx 备份：$backup"
