from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json, os, re, sqlite3
from contextlib import closing

DB = os.environ.get('VISIT_DB', '/var/lib/guoyuan-app-visits/visits.sqlite3')
PAGES = {'home', 'settings', 'smart_qa', 'smart_qa_history', 'environment', 'disease', 'disease_history', 'planting', 'nutrition', 'traceability'}
UUID = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$')

def initialise():
    with closing(sqlite3.connect(DB, timeout=10)) as db, db:
        db.execute('CREATE TABLE IF NOT EXISTS app_visits (id INTEGER PRIMARY KEY, device_id TEXT NOT NULL, page TEXT NOT NULL, visited_at TEXT NOT NULL DEFAULT (datetime(\'now\',\'localtime\')))')
        db.execute('CREATE INDEX IF NOT EXISTS app_visits_page_time ON app_visits(page, visited_at)')

def insert_event(body):
    obj = json.loads(body)
    if not isinstance(obj, dict): raise ValueError('invalid')
    device, page = obj.get('device_id'), obj.get('page')
    if not isinstance(device, str) or not UUID.fullmatch(device) or page not in PAGES: raise ValueError('invalid')
    with closing(sqlite3.connect(DB, timeout=10)) as db, db:
        db.execute('INSERT INTO app_visits(device_id,page) VALUES(?,?)', (device, page))

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != '/app-visit-events': self.send_error(404); return
        try:
            n = int(self.headers.get('Content-Length', '-1'))
            if n <= 0 or n > 1024: raise ValueError('invalid length')
            insert_event(self.rfile.read(n))
        except (ValueError, TypeError, UnicodeError): self.send_error(400); return
        except sqlite3.Error: self.send_error(503); return
        self.send_response(204); self.end_headers()
    def log_message(self, *args): pass

if __name__ == '__main__':
    os.makedirs(os.path.dirname(DB), mode=0o700, exist_ok=True)
    initialise()
    ThreadingHTTPServer(('127.0.0.1', 21002), Handler).serve_forever()
